import yfinance as yf
from datetime import datetime
import pytz

INDIA = pytz.timezone("Asia/Kolkata")
TICKERS = [
    "RELIANCE.NS", "TCS.NS", "INFY.NS", "HDFCBANK.NS", "ICICIBANK.NS",
    "LT.NS", "SBIN.NS", "KOTAKBANK.NS", "ITC.NS", "AXISBANK.NS"
]

def fetch_top_movers():
    results = []
    for ticker in TICKERS:
        data = yf.download(ticker, period="1d", interval="5m")
        if len(data) < 2:
            continue
        open_5min = data.iloc[1]['Close']
        latest = data.iloc[-1]['Close']
        pct_change = ((latest - open_5min) / open_5min) * 100
        if pct_change > 1:
            results.append({
                "ticker": ticker,
                "open_5min": round(open_5min, 2),
                "current": round(latest, 2),
                "change%": round(pct_change, 2)
            })
    return results
