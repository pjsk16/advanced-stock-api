import yfinance as yf
import xgboost as xgb
import pandas as pd

def predict_stock(ticker):
    df = yf.download(ticker, period="5d", interval="15m")
    df['returns'] = df['Close'].pct_change()
    df['target'] = (df['returns'].shift(-1) > 0).astype(int)
    df.dropna(inplace=True)

    features = ['Open', 'High', 'Low', 'Close', 'Volume']
    X = df[features]
    y = df['target']

    model = xgb.XGBClassifier()
    model.fit(X[:-1], y[:-1])

    pred_prob = model.predict_proba([X.iloc[-1]])[0][1]
    return round(pred_prob * 100, 2)
