from fastapi import FastAPI
from services.fetcher import fetch_top_movers
from services.predictor import predict_stock

app = FastAPI()

@app.get("/")
def root():
    return {"message": "Advanced Trading Platform API running"}

@app.get("/live-movers")
def get_movers():
    return {"top_movers": fetch_top_movers()}

@app.get("/predict/{ticker}")
def get_prediction(ticker: str):
    return {"ticker": ticker, "prediction_confidence": predict_stock(ticker)}
